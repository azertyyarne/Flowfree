﻿Option Explicit On

Public Class Form1
    Dim rooster(4, 4) As Label
    Dim Red, Green, Blue, Yellow As Integer
    Dim x As Integer = 0
    Dim y As Integer = 0
    Dim Headx As New List(Of Integer)
    Dim Heady As New List(Of Integer)
    Dim Tailx As New List(Of Integer)
    Dim Taily As New List(Of Integer)
    Dim Yay As Boolean = False
    Dim dragging As Boolean = False
    Dim SELECTED_COLOR As Color = Color.Gray
    Dim Kleur As New List(Of Color)
    Dim Backx As New List(Of Integer)
    Dim Backy As New List(Of Integer)
    Dim Yay2 As Boolean = False



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DrawMatrix()


    End Sub



    Private Sub DrawMatrix() 'Komt uit de tips van de opdracht
        'Matrix van 5 breed (tot 4) en 5 hoog (tot 4)

        'Maakt een 'leeg' rooster met leeg bedoel ik dat de kleur van dit rooster niet één is van de kleuren gebruikt om het spel zelf te spelen
        For i As Integer = rooster.GetLowerBound(0) To rooster.GetUpperBound(0)
            For j As Integer = rooster.GetLowerBound(1) To rooster.GetUpperBound(1)
                rooster(i, j) = New Label
                rooster(i, j).Size = New Size(30, 30)
                rooster(i, j).Name = "tile_" & i & "_" & j
                'x,y locatie in het venster
                rooster(i, j).Location = New Point(i * 31, j * 31)
                'kleur van het vierkantje
                Dim rnd As System.Random = New Random()
                rooster(i, j).BackColor = Color.Gray
                Me.Controls.Add(rooster(i, j))
                AddHandler rooster(i, j).MouseDown, AddressOf MouseDownHandler 'volgende drie lijnen uit voorbeeld van forum
                AddHandler rooster(i, j).MouseUp, AddressOf MouseUpHandler
                AddHandler rooster(i, j).MouseEnter, AddressOf MouseEnterHandler
            Next
        Next

    End Sub



    Private Sub Random_color()
        Dim index As Integer = 0
        Dim rnd As System.Random = New Random()
        index = 0

        While index < 5
            ' Volgende 2 lijnen komen uit de tips van de opdracht
            Dim x As Integer = rnd.Next(0, rooster.GetLength(0) - 1)
            Dim y As Integer = rnd.Next(0, rooster.GetLength(1) - 1)

            Dim Buur As Boolean = False

            While Buur = False 'Volgend kijkt na of (x,y) en minstens één van zijn buren leeg is (ik heb het ingewikeld gemaakt ik weet het, maar het werkt :) )
                While rooster(x, y).BackColor <> Color.Gray And x < 5

                    x = x + 1
                    If x = 5 Then
                        x = 0
                        If y < 5 Then
                            y = y + 1
                            If y = 5 Then
                                x = 0
                                y = 0
                            End If
                        End If
                    End If
                End While
                If x < 4 Then
                    If rooster(x + 1, y).BackColor = Color.Gray Then
                        Buur = True

                    ElseIf y < 4 Then
                        If rooster(x, y + 1).BackColor = Color.Gray Then
                            Buur = True

                        ElseIf x <> 0 Then
                            If rooster(x - 1, y).BackColor = Color.Gray Then
                                Buur = True
                            ElseIf y <> 0 Then
                                If rooster(x, y - 1).BackColor = Color.Gray Then
                                    Buur = True
                                End If
                            End If
                        End If
                    End If

                ElseIf y < 4 Then
                    If rooster(x, y + 1).BackColor = Color.Gray Then
                        Buur = True

                    ElseIf x <> 0 Then
                        If rooster(x - 1, y).BackColor = Color.Gray Then
                            Buur = True

                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = Color.Gray Then
                                Buur = True
                            End If
                        End If
                    End If

                ElseIf x <> 0 Then
                    If rooster(x - 1, y).BackColor = Color.Gray Then
                        Buur = True

                    ElseIf y <> 0 Then
                        If rooster(x, y - 1).BackColor = Color.Gray Then
                            Buur = True
                        End If
                    End If
                End If
                If Buur = False Then
                    x = x + 1
                    If x = 5 Then
                        x = 0
                        y = y + 1
                        If y = 5 Then
                            y = 0
                        End If
                    End If
                End If
            End While
            Red = rnd.Next(255)
            Blue = rnd.Next(255)
            Green = rnd.Next(255)   'Op dit punt weet men dat (x,y) leeg is en minstens één van zijn buren ook)
            If rooster(x, y).BackColor = Color.Gray And x < 5 Then
                rooster(x, y).BackColor = Color.FromArgb(Red, Green, Blue)
                Headx.Add(x)
                Heady.Add(y)
                If x < 4 Then
                    If rooster(x + 1, y).BackColor = Color.Gray Then
                        rooster(x + 1, y).BackColor = rooster(x, y).BackColor
                        Tailx.Add(x + 1)
                        Taily.Add(y)
                    ElseIf y < 4 Then
                        If rooster(x, y + 1).BackColor = Color.Gray Then
                            rooster(x, y + 1).BackColor = rooster(x, y).BackColor
                            Tailx.Add(x)
                            Taily.Add(y + 1)
                        ElseIf x <> 0 Then
                            If rooster(x - 1, y).BackColor = Color.Gray Then
                                rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                                Tailx.Add(x - 1)
                                Taily.Add(y)
                            ElseIf y <> 0 Then
                                If rooster(x, y - 1).BackColor = Color.Gray Then
                                    rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                                    Tailx.Add(x)
                                    Taily.Add(y - 1)
                                End If
                            End If
                        End If
                    End If
                ElseIf y < 4 Then
                    If rooster(x, y + 1).BackColor = Color.Gray Then
                        rooster(x, y + 1).BackColor = rooster(x, y).BackColor
                        Tailx.Add(x)
                        Taily.Add(y + 1)

                    ElseIf x <> 0 Then
                        If rooster(x - 1, y).BackColor = Color.Gray Then
                            rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                            Tailx.Add(x - 1)
                            Taily.Add(y)

                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = Color.Gray Then
                                rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                                Tailx.Add(x)
                                Taily.Add(y - 1)
                            End If
                        End If
                    End If

                ElseIf x <> 0 Then
                    If rooster(x - 1, y).BackColor = Color.Gray Then
                        rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                        Tailx.Add(x - 1)
                        Taily.Add(y)

                    ElseIf y <> 0 Then
                        If rooster(x, y - 1).BackColor = Color.Gray Then
                            rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                            Tailx.Add(x)
                            Taily.Add(y - 1)
                        End If
                    End If
                End If
            End If

            index = index + 1


        End While
    End Sub
    Private Sub Buren_kleuren_staart() 'Kleurt de buren van de staart
        Dim i As Integer = 0
        Dim Buur_vrij As Boolean = True

        While i < 5

            While Buur_vrij = True
                Buur_vrij = False
                x = Tailx(i)
                y = Taily(i)
                If x < 4 Then
                    If rooster(x + 1, y).BackColor = Color.Gray Then
                        rooster(x + 1, y).BackColor = rooster(x, y).BackColor
                        Tailx(i) = x + 1
                        Taily(i) = y
                        Buur_vrij = True
                    ElseIf y < 4 Then
                        If rooster(x, y + 1).BackColor = Color.Gray Then
                            rooster(x, y + 1).BackColor = rooster(x, y).BackColor
                            Tailx(i) = x
                            Taily(i) = y + 1
                            Buur_vrij = True
                        ElseIf x <> 0 Then
                            If rooster(x - 1, y).BackColor = Color.Gray Then
                                rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                                Tailx(i) = x - 1
                                Taily(i) = y
                                Buur_vrij = True
                            ElseIf y <> 0 Then
                                If rooster(x, y - 1).BackColor = Color.Gray Then
                                    rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                                    Tailx(i) = x
                                    Taily(i) = y - 1
                                    Buur_vrij = True
                                End If
                            End If
                        End If
                    End If
                ElseIf y < 4 Then
                    If rooster(x, y + 1).BackColor = Color.Gray Then
                        rooster(x, y + 1).BackColor = rooster(x, y).BackColor
                        Tailx(i) = x
                        Taily(i) = y + 1
                        Buur_vrij = True
                    ElseIf x <> 0 Then
                        If rooster(x - 1, y).BackColor = Color.Gray Then
                            rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                            Tailx(i) = x - 1
                            Taily(i) = y
                            Buur_vrij = True
                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = Color.Gray Then
                                rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                                Tailx(i) = x
                                Taily(i) = y - 1
                                Buur_vrij = True
                            End If
                        End If
                    End If

                ElseIf x <> 0 Then
                    If rooster(x - 1, y).BackColor = Color.Gray Then
                        rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                        Tailx(i) = x - 1
                        Taily(i) = y
                        Buur_vrij = True
                    ElseIf y <> 0 Then
                        If rooster(x, y - 1).BackColor = Color.Gray Then
                            rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                            Tailx(i) = x
                            Taily(i) = y - 1
                            Buur_vrij = True
                        End If
                    End If
                End If
            End While
            i = i + 1
            Buur_vrij = True
        End While

    End Sub
    Private Sub Buren_kleuren_kop() 'Kleurt de buren van de kop
        Dim i As Integer = 0
        Dim Buur_vrij As Boolean = True

        While i < 5

            While Buur_vrij = True
                Buur_vrij = False
                x = Headx(i)
                y = Heady(i)
                If x < 4 Then
                    If rooster(x + 1, y).BackColor = Color.Gray Then
                        rooster(x + 1, y).BackColor = rooster(x, y).BackColor
                        Headx(i) = x + 1
                        Heady(i) = y
                        Buur_vrij = True
                    ElseIf y < 4 Then
                        If rooster(x, y + 1).BackColor = Color.Gray Then
                            rooster(x, y + 1).BackColor = rooster(x, y).BackColor
                            Headx(i) = x
                            Heady(i) = y + 1
                            Buur_vrij = True
                        ElseIf x <> 0 Then
                            If rooster(x - 1, y).BackColor = Color.Gray Then
                                rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                                Headx(i) = x - 1
                                Heady(i) = y
                                Buur_vrij = True
                            ElseIf y <> 0 Then
                                If rooster(x, y - 1).BackColor = Color.Gray Then
                                    rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                                    Headx(i) = x
                                    Heady(i) = y - 1
                                    Buur_vrij = True
                                End If
                            End If
                        End If
                    End If
                ElseIf y < 4 Then
                    If rooster(x, y + 1).BackColor = Color.Gray Then
                        rooster(x, y + 1).BackColor = rooster(x, y).BackColor
                        Headx(i) = x
                        Heady(i) = y + 1
                        Buur_vrij = True
                    ElseIf x <> 0 Then
                        If rooster(x - 1, y).BackColor = Color.Gray Then
                            rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                            Headx(i) = x - 1
                            Heady(i) = y
                            Buur_vrij = True
                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = Color.Gray Then
                                rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                                Headx(i) = x
                                Heady(i) = y - 1
                                Buur_vrij = True
                            End If
                        End If
                    End If

                ElseIf x <> 0 Then
                    If rooster(x - 1, y).BackColor = Color.Gray Then
                        rooster(x - 1, y).BackColor = rooster(x, y).BackColor
                        Headx(i) = x - 1
                        Heady(i) = y
                        Buur_vrij = True
                    ElseIf y <> 0 Then
                        If rooster(x, y - 1).BackColor = Color.Gray Then
                            rooster(x, y - 1).BackColor = rooster(x, y).BackColor
                            Headx(i) = x
                            Heady(i) = y - 1
                            Buur_vrij = True
                        End If
                    End If
                End If
            End While
            i = i + 1
            Buur_vrij = True
        End While

    End Sub


    Private Sub Is_er_iets_grijs() 'Kijkt of het spelbord vol zit met kleuren

        x = 0
        y = 0
        While rooster(x, y).BackColor <> Color.Gray And Yay = False
            x = x + 1
            If x = 5 Then
                x = 0
                If y < 5 Then
                    y = y + 1
                    If y = 5 Then
                        y = 0
                        Yay = True
                    End If
                End If
            End If
        End While
        If Yay = False Then
            Headx.Clear()
            Heady.Clear()
            Tailx.Clear()
            Taily.Clear()
            Clear()
        End If
    End Sub


    Private Sub Oplossing_checken() 'Kijkt of het spelbord vol zit met kleuren

        x = 0
        y = 0
        While rooster(x, y).BackColor <> Color.Gray And Yay2 = False
            x = x + 1
            If x = 5 Then
                x = 0
                If y < 5 Then
                    y = y + 1
                    If y = 5 Then
                        y = 0
                        Yay2 = True
                    End If
                End If
            End If
        End While

    End Sub





    Private Sub Clear()     'Maakt het spelbord leeg
        For i As Integer = rooster.GetLowerBound(0) To rooster.GetUpperBound(0)
            For j As Integer = rooster.GetLowerBound(1) To rooster.GetUpperBound(1)

                rooster(i, j).BackColor = Color.Gray

            Next
        Next
    End Sub



    Private Sub Draw_head_and_tail()    'Zoals de naam zegt, het gaat de koppen en staarten tekenen nadat ze opgeslagen zijn geweest
        Dim i As Integer = 0
        Dim rnd As System.Random = New Random()
        While i < 5
            x = Headx(i)
            y = Heady(i)
            Red = rnd.Next(255)
            Blue = rnd.Next(255)
            Green = rnd.Next(255)
            rooster(x, y).BackColor = Color.FromArgb(Red, Green, Blue)
            x = Tailx(i)
            y = Taily(i)
            rooster(x, y).BackColor = Color.FromArgb(Red, Green, Blue)
            i = i + 1
        End While


    End Sub

    Private Sub Button3_MouseClick(sender As Object, e As MouseEventArgs) Handles Button4.MouseClick
        Clear()
        Draw_head_and_tail()
    End Sub

    Private Sub Kleuren_kop_staart_bijhouden()
        Kleur.Clear()
        Dim i As Integer = 0
        While i < 5
            x = Headx(i)
            y = Heady(i)
            Kleur.Add(rooster(x, y).BackColor)
            i = i + 1
        End While
    End Sub

    Private Sub Button4_MouseClick(sender As Object, e As MouseEventArgs) Handles Button3.MouseClick
        Label1.Text = 0
        Label2.Text = ""
        Yay = False
        Headx.Clear()
        Heady.Clear()
        Tailx.Clear()
        Taily.Clear()
        Clear()
        While Yay = False
            Random_color()
            Buren_kleuren_staart()
            Buren_kleuren_kop()
            Is_er_iets_grijs()
        End While
        Clear()
        Draw_head_and_tail()
        Kleuren_kop_staart_bijhouden()
        Timer1.Enabled = True



    End Sub


    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick 'de timer heb ik uit volgende link: https://www.vbtutor.net/vb2010/vb2010_lesson27.html
        'To increase one unit per second
        Label1.Text = Val(Label1.Text) + 1
    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub MouseDownHandler(ByVal label As Label, ByVal e As MouseEventArgs)   'kijkt of de muis zich wel op een kop of staart bevind tijdens het klikken
        dragging = False
        label.Capture = False


        Dim a As Integer                        'x van de kop of staart verderop
        Dim b As Integer                        'y van de kop of staart verderop
        Dim i As Integer = 0

        While rooster(x, y) IsNot label
            x = x + 1
            If x = 5 Then
                x = 0
                If y < 5 Then
                    y = y + 1
                    If y = 5 Then
                        y = 0

                    End If
                End If
            End If
        End While

        While i < 5 And dragging = False
            a = Tailx(i)
            b = Taily(i)
            If x = a And y = b Then
                dragging = True
            End If
            i = i + 1
        End While
        i = 0
        While i < 5 And dragging = False
            a = Headx(i)
            b = Heady(i)
            If x = a And y = b Then
                dragging = True
            End If
            i = i + 1
        End While

        If label.BackColor <> Color.Gray Then
            SELECTED_COLOR = label.BackColor

        End If

    End Sub

    Private Sub MouseUpHandler(ByVal label As Label, ByVal e As MouseEventArgs)     'Verwijderd eventueel wat er getekend is wanneer het fout is
        dragging = False
        Dim Head_to_tail As Boolean = False     'Is de kop met de staart verbonden?
        Dim a As Integer                        'x van de kop of staart verderop
        Dim b As Integer                        'y van de kop of staart verderop
        For Each lab As Label In rooster
            Dim i As Integer = 0


            While rooster(x, y) IsNot label
                x = x + 1
                If x = 5 Then
                    x = 0
                    If y < 5 Then
                        y = y + 1
                        If y = 5 Then
                            y = 0

                        End If
                    End If
                End If
            End While

            While i < 5 And Head_to_tail = False
                a = Tailx(i)
                b = Taily(i)
                If x = a And y = b Then
                    Head_to_tail = True
                End If
                i = i + 1
            End While
            i = 0
            While i < 5 And Head_to_tail = False
                a = Headx(i)
                b = Heady(i)
                If x = a And y = b Then
                    Head_to_tail = True
                End If
                i = i + 1
            End While

            i = 0
            If Head_to_tail = False Then

                While i < Backx.Count   'Reseten van het gekleurde gedeelte
                    x = Backx(i)
                    y = Backy(i)
                    rooster(x, y).BackColor = Color.Gray
                    i = i + 1
                End While

            End If
            Backx.Clear()
            Backy.Clear()
            If dragging = False Then    'Volgend is een poging tot het reseten wanneer men over dezelfde lijn terug gaat naar de kop
                i = 0
                While i < Backx.Count
                    x = Backx(i)
                    y = Backy(i)
                    rooster(x, y).BackColor = Color.Gray
                    i = i + 1
                End While

            End If
            Backx.Clear()
            Backy.Clear()

        Next

        If Yay2 = False Then
            Oplossing_checken()
        End If
        If Yay2 = True Then
            Timer1.Enabled = False
            Label2.Text = "Gefeliciteerd!"
        End If

    End Sub

    Private Sub MouseEnterHandler(ByVal label As Label, ByVal e As EventArgs)   'kijkt na of je wel in 1 lijn door aan het tekenen bent  en of de kleur van het vakje wel grijs is voor je gaat kleuren




        If dragging Then


            Dim i As Integer = 0
            Dim Neigbour As Boolean = True

            dragging = False

            While rooster(x, y) IsNot label
                x = x + 1
                If x = 5 Then
                    x = 0
                    If y < 5 Then
                        y = y + 1
                        If y = 5 Then
                            y = 0

                        End If
                    End If
                End If
            End While
            'Begin kijken of buur wel van zelfde kleur Is
            'weeral het is slordig maar het werkt wel
            While dragging = False


                If x < 4 Then
                    If rooster(x + 1, y).BackColor = SELECTED_COLOR Then


                        dragging = True
                    ElseIf y < 4 Then
                        If rooster(x, y + 1).BackColor = SELECTED_COLOR Then
                            dragging = True
                        ElseIf x <> 0 Then
                            If rooster(x - 1, y).BackColor = SELECTED_COLOR Then
                                dragging = True
                            ElseIf y <> 0 Then
                                If rooster(x, y - 1).BackColor = SELECTED_COLOR Then
                                    dragging = True
                                End If
                            End If
                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = SELECTED_COLOR Then
                                dragging = True
                            End If
                        End If
                    ElseIf x <> 0 Then
                        If rooster(x - 1, y).BackColor = SELECTED_COLOR Then
                            dragging = True
                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = SELECTED_COLOR Then
                                dragging = True
                            End If
                        End If
                    End If
                ElseIf y < 4 Then
                    If rooster(x, y + 1).BackColor = SELECTED_COLOR Then

                        dragging = True
                    ElseIf x <> 0 Then
                        If rooster(x - 1, y).BackColor = SELECTED_COLOR Then

                            dragging = True
                        ElseIf y <> 0 Then
                            If rooster(x, y - 1).BackColor = SELECTED_COLOR Then

                                dragging = True
                            End If
                        End If
                    End If

                ElseIf x <> 0 Then
                    If rooster(x - 1, y).BackColor = SELECTED_COLOR Then

                        dragging = True
                    ElseIf y <> 0 Then
                        If rooster(x, y - 1).BackColor = SELECTED_COLOR Then

                            dragging = True
                        End If
                    End If
                ElseIf y <> 0 Then
                    If rooster(x, y - 1).BackColor = SELECTED_COLOR Then

                        dragging = True
                    End If
                End If
                If dragging = False Then
                    Neigbour = False
                    dragging = True
                End If
            End While

            If Neigbour = False Then
                dragging = False
            End If


            If label.BackColor = Color.Gray Then    'deze if zorgt ervoor dat men niet tijdens het kleuren over dezelfde lijn kan teruggaan en hieruit verder kan tekenen
            Else                                    'maar wel kan ik niet de fout wegkrijgen dat je over een lijn kan teruggaan naar dezelfde kop waardoor deze oplossing 'juist' is
                dragging = False
            End If
            If dragging Then
                label.BackColor = SELECTED_COLOR

                Backx.Add(x)
                Backy.Add(y)

            End If

        End If


    End Sub


End Class
